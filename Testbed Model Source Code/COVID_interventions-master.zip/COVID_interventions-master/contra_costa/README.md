All fits and simulations can now be run one folder up
